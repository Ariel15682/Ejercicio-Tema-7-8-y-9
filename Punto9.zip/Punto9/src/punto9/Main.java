package punto9;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * Programa de oferta educativa
 * @author Ariel Sergio Diaz
 */

public class Main {
    
    public static void main(String[] args) throws FileNotFoundException {
              
        inicio(leerBBDD());
                                  
    }
   
    
    public static void inicio(HashMap<String,String> lista) throws FileNotFoundException{
        
        Scanner scannerInt = new Scanner(System.in);
        Scanner scannerString = new Scanner(System.in);//para sanear el problema del salto de linea
        
                
        int opcionSeleccionada = 0;
        String codigoCurso;
        String nombreCurso;        
        
        while(opcionSeleccionada != 5){
            System.out.println("Por favor, selecciona una opcion");
            System.out.println("1 - Agregar Curso");
            System.out.println("2 - Borrar Curso");
            System.out.println("3 - Mostrar Cursos");
            System.out.println("4 - Buscar Cursos");
            System.out.println("5 - Salir");
            
            try{
                opcionSeleccionada = scannerInt.nextInt();
            }catch(Exception e1){
                System.out.println("Debe introducir un numero " + e1.getMessage());
                inicio(leerBBDD());
            } 
            
                               
            switch(opcionSeleccionada){
                case 1: 
                    System.out.println("Por favor, introduzca el codigo del curso que desea agregar");
                    codigoCurso = scannerString.nextLine();
                    System.out.println("Por favor, introduzca el nombre del curso");
                    nombreCurso = scannerString.nextLine();
                    System.out.println("");
                    guardarCurso(codigoCurso, nombreCurso, lista);
                    break;
                case 2: 
                    System.out.println("Por favor, introduzca el codigo del curso que desea borrar");
                    codigoCurso = scannerString.nextLine();
                    System.out.println("");
                    borrarCurso(codigoCurso, lista);
                    break;
                case 3:
                    mostrarCursos(lista);
                    break;
                case 4:
                    subMenu(lista);
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("La opcion ingreasada no es valida");
                    System.out.println("");
                    break;
            }
        }        
    }
    
    
    public static void subMenu(HashMap<String,String> lista) throws FileNotFoundException{
        Scanner scInt = new Scanner(System.in);
        Scanner scString = new Scanner(System.in);
        int opcionSubMenu = 0;
        String codigoSubMenu; 
        String nombreSubMenu;
               
        while(opcionSubMenu != 3){
                        System.out.println("Seleccionar busqueda:");
                        System.out.println("1 - Busqueda por codigo");
                        System.out.println("2 - Busqueda por nombre");
                        System.out.println("3 - Volver");
                                                
                        try{
                            opcionSubMenu = scInt.nextInt();
                        }catch(Exception e2){
                            System.out.println("Debe introducir un numero " + e2.getMessage());
                            inicio(leerBBDD());
                        }
                        
                        
                        switch(opcionSubMenu){
                            case 1:
                                System.out.println("Ingrese codigo");
                                codigoSubMenu = scString.nextLine();
                                System.out.println("");
                                busquedaCodigo(codigoSubMenu,lista);
                                break;
                            case 2:
                                System.out.println("Ingrese nombre");
                                nombreSubMenu = scString.nextLine();
                                System.out.println("");
                                busquedaNombre(nombreSubMenu,lista);
                                break;
                            case 3:
                                break;
                            default: 
                                System.out.println("La opcion ingreasada no es valida");
                                System.out.println("");
                                break;
                        }
        }
    }
    
    public static void guardarCurso(String codigo, String nombre, HashMap<String,String> lista) throws FileNotFoundException{
               
        try{PrintStream out = new PrintStream("/Users/QSP/Desktop/BBDD.txt");
            if(lista.containsKey(codigo)){
                out.print(lista);
                out.close();
                System.out.println("El codigo/curso ya existe");
            } else { lista.put(codigo, nombre);
                     out.print(lista);
                     out.close();}
        }catch(Exception excepcion){
            System.out.println("Error " + excepcion.getMessage());
        }
        
        System.out.println("");
    }
    
    public static void borrarCurso(String codigo, HashMap<String,String> lista){
        if(lista.containsKey(codigo)){
            lista.remove(codigo);
        } else { System.out.println("El codigo/curso no existe"); }
        System.out.println("");
    }
    
    public static void mostrarCursos(HashMap<String,String> lista){
        if(lista.isEmpty()){
              System.out.println("No hay cursos cargados");  
        }else{System.out.println("Estos son los cursos que actualmente existen...");
              System.out.println(lista.entrySet()); }
        System.out.println("");
    }

    public static void busquedaCodigo(String codigo, HashMap<String, String> lista) {
        if(lista.containsKey(codigo)){
                System.out.println(lista.get(codigo));
        } else {System.out.println("El codigo no existe");}
        System.out.println("");
    }
    
    public static void busquedaNombre(String nombre, HashMap<String, String> lista) {
        LinkedList<String> clave = new LinkedList<>(lista.keySet());
        LinkedList<String> valor = new LinkedList<>(lista.values());
        boolean existe = false;
        
        for(int i = 0; i < valor.size(); i++){
            if(valor.get(i).contains(nombre)){
                existe = true;
                System.out.println("El nombre: " + valor.get(i) + " se encuentra con el codigo: " + clave.get(i));
            }
        }
            if(!existe){System.out.println("El nombre no existe");}
        System.out.println("");
    }
   
    public static HashMap<String, String> leerBBDD() throws FileNotFoundException{
        HashMap<String,String> listaCursos = new HashMap<>(); //key = Integer (codigo curso)
        FileInputStream in = new FileInputStream("/Users/QSP/Desktop/BBDD.txt"); 
                
        int dato;
        String datos = "";
                
        try{ 
            dato = in.read();
                                   
            while (dato != -1){
                
                datos = datos + (char)dato;
                dato = in.read();
            }
               in.close();
               
               String key, value;
               datos = datos.substring(0, datos.length()-1);
               //System.out.println(datos);
               String[] parts = datos.split(",");
               for(int i = 0; i < parts.length; i++){
                     //System.out.println(parts[i]);
                     String[] subParts = parts[i].split("=");
                     key = subParts[0].substring(1, subParts[0].length());
                     value = subParts[1].substring(0, subParts[1].length());
                     listaCursos.put(key, value);
               }
               
        }catch(Exception excepcion){
            System.out.println("Error " + excepcion.getMessage());
        }
                
        return listaCursos;        
    } 
    
}

//borra base de datos